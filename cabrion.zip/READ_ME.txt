----------IMPORTANT NOTE----------

This version is absolutely free for personal, educational, non-profit, or charitable use.
For commercial use, available on Font Marketplace

contact: anugrahtaccidix@gmail.com

Thanks for being supportive

instagram.com/lafontype
behance.net/lafontype